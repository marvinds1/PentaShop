# Flask-Login-Register
A Simple Login &amp; Register Page Using Flask.

Creating the database:
```
pip3 install -r requirements.txt
cd backend
python3
from app import db
db.create_all()
```
